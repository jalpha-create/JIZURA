JIZURA English CEP panel

Extract this ZIP and run install_win.bat or install_mac.command. Restart After Effects and open Window > Extensions > JIZURA English. It can coexist with the Japanese panel.
